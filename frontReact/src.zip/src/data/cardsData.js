// preview-карточки и их «дополнения» для модалки
const cardsData = [
   {
     id: 'ecto',
     src: '/gallery/img1.jpg',
     name: 'Эктоморф',
     description: 'Высокий и худощавый',
     details: [
       {
         src: '/gallery/ecto_plan1.jpg',
         name: 'План питания эктоморфа',
         description: 'Калорийный рацион для набора массы'
       },
       {
         src: '/gallery/ecto_workout1.jpg',
         name: 'Тренировка эктоморфа',
         description: 'Комплекс упражнений с упором на силу'
       },
       // …можно сколько угодно…
     ]
   },
   {
     id: 'meso',
     src: '/gallery/img2.jpg',
     name: 'Мезоморф',
     description: 'Нормальный тип телосложения',
     details: [
       {
         src: '/gallery/meso_plan1.jpg',
         name: 'Рацион мезоморфа',
         description: 'Сбалансированная диета для поддержания формы'
       },
       {
         src: '/gallery/meso_workout1.jpg',
         name: 'Тренировка мезоморфа',
         description: 'Сочетание кардио и силовых упражнений'
       },
     ]
   },
   {
     id: 'endo',
     src: '/gallery/img3.jpg',
     name: 'Эндоморф',
     description: 'Крупный плотный тип',
     details: [
       {
         src: '/gallery/endo_plan1.jpg',
         name: 'Рацион эндоморфа',
         description: 'Диета с контролем углеводов'
       },
       {
         src: '/gallery/endo_workout1.jpg',
         name: 'Тренировка эндоморфа',
         description: 'Интервальные кардио и базовые упражнения'
       },
     ]
   },
   // …остальные превью…
 ]
 
 export default cardsData
 