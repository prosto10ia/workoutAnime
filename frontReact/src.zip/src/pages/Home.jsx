import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Header from '../components/Header'
import Footer from '../components/Footer'
import CardGallery from '../components/CardGallery'
import cardsData from '../data/cardsData'

export default function Home() {
  const navigate = useNavigate()
  const [selectedDetail, setSelectedDetail] = useState(null)

  const handleSelect = (detailCard) => {
    setSelectedDetail(detailCard)
    // можно навигировать дальше, передав в state detailCard
    navigate('/select', { state: { selected: detailCard } })
  }

  return (
    <>
      <Header title="Главная — Anime Workout" />
      <main style={{ padding: '24px' }}>
        <h2>Welcome! Choose your body type:</h2>

        <CardGallery
          cards={cardsData}
          previewCount={cardsData.length}
          onSelect={handleSelect}
        />

        {selectedDetail && (
          <div style={{ marginTop: '32px', color: 'var(--text-primary)' }}>
            <h3>Выбрано дополнение:</h3>
            <strong>{selectedDetail.name}</strong>
            <p>{selectedDetail.description}</p>
            <img
              src={selectedDetail.src}
              alt={selectedDetail.name}
              style={{ width: '150px', borderRadius: '4px' }}
            />
          </div>
        )}
      </main>
      <Footer />
    </>
  )
}