import React from 'react';
import '../styles/components/characterCard.css';

const CharacterCard = ({ imageSrc, name, description, onClick }) => (
  <div className="card" onClick={onClick}>
    <div className="card__image-wrapper">
      <img src={imageSrc} alt={name} className="card__image" />
    </div>
    <div className="card__body">
      <h3 className="card__name">{name}</h3>
      <p className="card__description">{description}</p>
    </div>
  </div>
);

export default CharacterCard;
