import React from 'react';

const Footer = () => (
  <footer>
    <p>&copy; 2025 Anime Workout</p>
  </footer>
);

export default Footer;