import React from 'react'
import CharacterCard from './CharacterCard'
import '../styles/components/galleryModal.css'

const GalleryModal = ({ onClose, onSelect }) => {
  const gallery = [
    { src: '/gallery/img1.jpg', name: 'Архетип 1', description: 'Короткое описание 1' },
    { src: '/gallery/img2.jpg', name: 'Архетип 2', description: 'Короткое описание 2' },
    { src: '/gallery/img3.jpg', name: 'Архетип 3', description: 'Короткое описание 3' },
    // можно добавить сколько угодно элементов
  ]

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <button className="modal__close" onClick={onClose} aria-label="Закрыть">
          ×
        </button>
        <div className="gallery-grid">
          {gallery.map((item, idx) => (
            <CharacterCard
              key={idx}
              imageSrc={item.src}
              name={item.name}
              description={item.description}
              onClick={() => {
                onSelect(item.src)
                onClose()
              }}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

export default GalleryModal
