import React, { useState } from 'react'
import CharacterCard from './CharacterCard'
import '../styles/components/cardGallery.css'

const CardGallery = ({ cards, onSelect, previewCount = cards.length }) => {
  const [modalOpen, setModalOpen] = useState(false)
  const [startIndex, setStartIndex] = useState(0)

  // Когда кликают по превью-карточке
  const handlePreviewClick = (idx) => {
    setStartIndex(idx)
    setModalOpen(true)
  }

  // Когда выбирают карточку внутри модалки
  const handleSelect = (card) => {
    onSelect(card)
    setModalOpen(false)
  }

  // Превью: первые previewCount карточек
  const previewCards = cards.slice(0, previewCount)

  return (
    <>
      {/* Превью-карточки */}
      <div className="gallery-preview">
        {previewCards.map((card, idx) => (
          <div key={idx} onClick={() => handlePreviewClick(idx)}>
            <CharacterCard
              imageSrc={card.src}
              name={card.name}
              description={card.description}
              onClick={() => {}}
            />
          </div>
        ))}
      </div>

      {/* Модалка галереи */}
      {modalOpen && (
        <div className="modal-overlay" onClick={() => setModalOpen(false)}>
          <div
            className="modal-content gallery-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="modal__close"
              onClick={() => setModalOpen(false)}
              aria-label="Закрыть"
            >
              ×
            </button>
            <div className="gallery-scroll" style={{ scrollSnapType: 'x mandatory', scrollBehavior: 'smooth' }}>
              {cards.map((card, idx) => (
                <div
                  key={idx}
                  className="gallery-scroll__item"
                  style={{ scrollSnapAlign: 'center' }}
                  onClick={() => handleSelect(card)}
                >
                  <CharacterCard
                    imageSrc={card.src}
                    name={card.name}
                    description={card.description}
                    onClick={() => {}}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export default CardGallery
